// api/data.js — Vercel serverless function.
// Keeps the Google Sheet URLs server-side. The browser only ever sees data
// it is entitled to, based on the token in the link.

// Which views (and audience variant) each tier unlocks.
const TIERS = {
  "fundraising-angel": { fundraising: "angel" },
  "fundraising-vc":    { fundraising: "vc" },
  "full-angel":        { fundraising: "angel", full: "angel" },
  "full-vc":           { fundraising: "vc",    full: "vc" },
};

// Maps a dataset key -> the environment variable holding that tab's CSV URL.
const CSV_ENV = {
  "fundraising-angel": "CSV_FUNDRAISING_ANGEL",
  "fundraising-vc":    "CSV_FUNDRAISING_VC",
  "full-angel":        "CSV_FULL_ANGEL",
  "full-vc":           "CSV_FULL_VC",
};

function loadAccessList() {
  try { return JSON.parse(process.env.ACCESS_LIST || "{}"); }
  catch (e) { console.error("ACCESS_LIST env var is not valid JSON:", e.message); return {}; }
}

module.exports = async (req, res) => {
  const token = String((req.query && req.query.token) || "").trim();
  const view  = String((req.query && req.query.view)  || "fundraising").trim();
  const permsOnly = String((req.query && req.query.permsOnly) || "") === "1";

  const list = loadAccessList();
  const person = token ? list[token] : null;

  if (!person) {
    return res.status(401).json({ error: "invalid_token" });
  }

  const tierViews = TIERS[person.tier];
  if (!tierViews) return res.status(403).json({ error: "unknown_tier", tier: person.tier });

  const permissions = { fundraising: !!tierViews.fundraising, full: !!tierViews.full };

  // Basic access log — visible in the Vercel dashboard under the function's logs.
  console.log(JSON.stringify({
    at: new Date().toISOString(), token, name: person.name || null,
    tier: person.tier, view, ua: (req.headers["user-agent"] || "").slice(0, 120),
  }));

  if (permsOnly) {
    return res.status(200).json({ name: person.name || "", permissions });
  }

  const audience = tierViews[view];
  if (!audience) {
    return res.status(403).json({ error: "view_not_allowed", view, permissions });
  }

  const datasetKey = view + "-" + audience;       // e.g. "fundraising-vc"
  const envName = CSV_ENV[datasetKey];
  const csvUrl = envName ? process.env[envName] : null;
  if (!csvUrl) {
    return res.status(500).json({ error: "dataset_not_configured", datasetKey, expectedEnv: envName });
  }

  try {
    const upstream = await fetch(csvUrl);
    if (!upstream.ok) throw new Error("upstream HTTP " + upstream.status);
    const csv = await upstream.text();
    res.setHeader("Cache-Control", "no-store");
    return res.status(200).json({ name: person.name || "", permissions, view, audience, csv });
  } catch (e) {
    return res.status(502).json({ error: "fetch_failed", detail: String(e && e.message || e) });
  }
};
