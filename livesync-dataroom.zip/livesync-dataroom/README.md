# LIVESYNC Dataroom

A private, tier-gated investor dataroom. Each investor gets a personal link.
The Google Sheet URLs live on the server and are never exposed to the browser.

## How it works

- Each investor gets a unique link: `https://your-site/?token=ax9k2m`
- The server looks up that token, sees the person's **tier**, and serves only
  the data they're entitled to.
- The four tiers:

  | Tier | Sees Fundraising | Sees Full Pack |
  |---|---|---|
  | Fundraising · Angel | Angel | — (locked) |
  | Fundraising · VC | VC | — (locked) |
  | Full · Angel | Angel | Angel |
  | Full · VC | VC | VC |

- On the fundraising page, the "Full Due Diligence Pack" panel is a live button
  for Full-tier people and a locked "Request access" state for everyone else.

## One-time setup

### 1. Publish your four sheet tabs as CSV
In Google Sheets: **File → Share → Publish to web**, pick the specific tab,
format **CSV**, Publish, copy the link. Do this for each of:
Fundraising Angel, Fundraising VC, Full Angel, Full VC.
Publish **only** these tabs — leave everything else unpublished.

### 2. Deploy to Vercel
1. Create a free account at vercel.com.
2. Put this folder in a **private** GitHub repo (or drag-and-drop the folder
   into Vercel's "new project" importer).
3. Deploy. Vercel gives you a web address like
   `https://livesync-dataroom.vercel.app`.

### 3. Add your environment variables
In Vercel: **Project → Settings → Environment Variables**. Add:

- `CSV_FUNDRAISING_ANGEL` — the Fundraising Angel CSV link
- `CSV_FUNDRAISING_VC` — the Fundraising VC CSV link
- `CSV_FULL_ANGEL` — the Full Angel CSV link
- `CSV_FULL_VC` — the Full VC CSV link
- `ACCESS_LIST` — your investor list (see next step)

Then redeploy (Vercel → Deployments → ⋯ → Redeploy) so the values take effect.

### 4. Generate links with the access manager
Open `admin.html` (just double-click it — it runs in your browser, nothing is
sent anywhere). Paste your Vercel web address, add each investor with their
tier, and:
- **Copy link** gives you the personal link to send that investor.
- **Copy access list** gives you the value to paste into the `ACCESS_LIST`
  environment variable on Vercel.

Whenever you add or remove someone, update `ACCESS_LIST` on Vercel and redeploy.

## Managing access

- **Add someone:** add them in `admin.html`, update `ACCESS_LIST`, redeploy.
- **Revoke someone:** remove them in `admin.html` (or delete their token from
  `ACCESS_LIST`), update Vercel, redeploy. Their link stops working.
- **Upgrade someone** (e.g. Fundraising VC → Full VC): change their tier in
  `admin.html`, update `ACCESS_LIST`, redeploy. Their existing link keeps
  working and now unlocks the full pack.
- **See who accessed what:** Vercel → your project → the `data` function's
  logs. Each visit logs the time, token, name, tier, and which view.

## Good to know

- Keep `admin.html` and your backup file to yourself — don't deploy `admin.html`
  publicly. (It isn't linked from the site, but best to keep it local.)
- Links can be forwarded by the recipient, like any share link. If you suspect a
  link has been shared, revoke that token and issue a fresh one.
- The data shown is read-only and always live from your sheet — edits appear on
  the next page refresh.

## Files

```
api/data.js            The server proxy (token -> tier -> data)
public/index.html      Entry point; forwards the token to the fundraising page
public/fundraising.html
public/full.html
admin.html             Local tool to generate links and the access list
.env.example           The environment variables you'll set on Vercel
```
